"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Check, Info, ShoppingCart, Shield, Leaf, BarChart, Building } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Textarea } from "@/components/ui/textarea"

// Sample credit packages
const creditPackages = [
  {
    id: 1,
    name: "Starter",
    amount: "10",
    price: "249",
    description: "Perfect for small businesses looking to offset their carbon footprint.",
    features: ["10 tons of CO₂ offset", "Blockchain certificate", "Monthly impact report"],
    popular: false,
  },
  {
    id: 2,
    name: "Business",
    amount: "50",
    price: "1,199",
    description: "Ideal for medium-sized companies with moderate carbon emissions.",
    features: [
      "50 tons of CO₂ offset",
      "Blockchain certificate",
      "Monthly impact report",
      "Customized sustainability badge",
    ],
    popular: true,
  },
  {
    id: 3,
    name: "Enterprise",
    amount: "250",
    price: "5,499",
    description: "Comprehensive solution for larger organizations with significant carbon footprints.",
    features: [
      "250 tons of CO₂ offset",
      "Blockchain certificate",
      "Monthly impact report",
      "Customized sustainability badge",
      "Dedicated account manager",
      "Annual sustainability consultation",
    ],
    popular: false,
  },
]

export default function PurchasePage() {
  const router = useRouter()
  const [selectedPackage, setSelectedPackage] = useState(creditPackages[1].id)
  const [quantity, setQuantity] = useState(1)
  const [activeTab, setActiveTab] = useState("packages")
  const [companyName, setCompanyName] = useState("")
  const [companyAddress, setCompanyAddress] = useState("")

  const selectedPkg = creditPackages.find((pkg) => pkg.id === selectedPackage)
  const totalPrice = selectedPkg ? Number.parseInt(selectedPkg.price.replace(",", "")) * quantity : 0
  const formattedTotalPrice = totalPrice.toLocaleString()

  const handleCheckout = () => {
    // Pass the selected package details and company info to the completion page
    const totalAmount = Number.parseInt(selectedPkg?.amount.replace(",", "") || "0") * quantity
    const params = new URLSearchParams({
      amount: totalAmount.toString(),
      package: selectedPkg?.name || "",
      companyName: companyName || "",
      companyAddress: companyAddress || "",
    })
    router.push(`/dashboard/purchase/complete?${params.toString()}`)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <h1 className="text-xl font-bold">ATMOSIEVE TECHNOLOGIES</h1>
              <Badge variant="outline" className="ml-2">
                Purchase
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <h2 className="text-3xl font-bold mb-2">Purchase Carbon Credits</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Offset your carbon footprint with verified carbon credits from ATMOSIEVE's atmospheric capture facilities.
            Each credit represents one metric ton of CO₂ removed from the atmosphere.
          </p>
        </div>

        <Tabs defaultValue="packages" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
            <TabsTrigger value="packages">Credit Packages</TabsTrigger>
            <TabsTrigger value="custom">Custom Amount</TabsTrigger>
          </TabsList>

          <TabsContent value="packages">
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {creditPackages.map((pkg) => (
                <Card
                  key={pkg.id}
                  className={`relative overflow-hidden ${
                    selectedPackage === pkg.id ? "border-2 border-blue-500" : ""
                  } ${pkg.popular ? "shadow-lg" : ""}`}
                >
                  {pkg.popular && (
                    <div className="absolute top-0 right-0">
                      <Badge className="m-2 bg-blue-500">Most Popular</Badge>
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle>{pkg.name}</CardTitle>
                    <CardDescription>{pkg.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <span className="text-3xl font-bold">${pkg.price}</span>
                      <span className="text-gray-500 ml-1">/ one-time</span>
                    </div>
                    <div className="text-lg font-medium mb-4">
                      <Leaf className="inline-block mr-2 h-5 w-5 text-green-500" />
                      {pkg.amount} Carbon Credits
                    </div>
                    <ul className="space-y-2">
                      {pkg.features.map((feature, index) => (
                        <li key={index} className="flex items-start">
                          <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className={`w-full ${selectedPackage === pkg.id ? "bg-blue-500 hover:bg-blue-600" : ""}`}
                      onClick={() => setSelectedPackage(pkg.id)}
                    >
                      {selectedPackage === pkg.id ? "Selected" : "Select Package"}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="custom">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle>Custom Credit Amount</CardTitle>
                <CardDescription>Specify the exact number of carbon credits you'd like to purchase.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  <div>
                    <Label htmlFor="custom-amount">Number of Credits</Label>
                    <div className="flex items-center mt-1.5">
                      <Input id="custom-amount" type="number" min="1" placeholder="Enter amount" className="w-full" />
                      <span className="ml-2 text-sm text-gray-500">tons CO₂</span>
                    </div>
                    <p className="text-sm text-gray-500 mt-1.5">
                      Each credit represents 1 metric ton of CO₂ removed from the atmosphere.
                    </p>
                  </div>
                  <div>
                    <Label>Credit Source</Label>
                    <RadioGroup defaultValue="all" className="mt-1.5">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="all" id="all" />
                        <Label htmlFor="all" className="cursor-pointer">
                          All Facilities
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="specific" id="specific" />
                        <Label htmlFor="specific" className="cursor-pointer">
                          Specific Facility
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Calculate Price</Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>

        {activeTab === "packages" && (
          <div className="max-w-3xl mx-auto mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-4 border-b">
                    <div>
                      <h3 className="font-medium">{selectedPkg?.name} Package</h3>
                      <p className="text-sm text-gray-500">{selectedPkg?.amount} Carbon Credits</p>
                    </div>
                    <div className="flex items-center">
                      <div className="flex items-center mr-6">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 rounded-full"
                          onClick={() => setQuantity(Math.max(1, quantity - 1))}
                          disabled={quantity <= 1}
                        >
                          -
                        </Button>
                        <span className="mx-3 w-8 text-center">{quantity}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 rounded-full"
                          onClick={() => setQuantity(quantity + 1)}
                        >
                          +
                        </Button>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">${formattedTotalPrice}</div>
                        <div className="text-sm text-gray-500">
                          ${selectedPkg?.price} × {quantity}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pb-4 border-b">
                    <div className="font-medium">Total Carbon Offset</div>
                    <div className="font-medium">
                      {Number.parseInt(selectedPkg?.amount.replace(",", "") || "0") * quantity} tons CO₂
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="font-medium text-lg">Total</div>
                    <div className="font-bold text-lg">${formattedTotalPrice}</div>
                  </div>
                </div>

                <Accordion type="single" collapsible className="mt-6">
                  <AccordionItem value="company-info">
                    <AccordionTrigger className="text-sm font-medium">
                      <div className="flex items-center">
                        <Building className="mr-2 h-4 w-4" />
                        Company Information (Optional)
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 pt-2">
                        <div className="grid gap-2">
                          <Label htmlFor="company-name">Company Name</Label>
                          <Input
                            id="company-name"
                            placeholder="Enter company name for certificate"
                            value={companyName}
                            onChange={(e) => setCompanyName(e.target.value)}
                          />
                          <p className="text-xs text-gray-500">
                            If left blank, "Contra Corporation" will be used on the certificate.
                          </p>
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="company-address">Company Address</Label>
                          <Textarea
                            id="company-address"
                            placeholder="Enter company address"
                            rows={3}
                            value={companyAddress}
                            onChange={(e) => setCompanyAddress(e.target.value)}
                          />
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Save for Later</Button>
                <Button className="bg-green-600 hover:bg-green-700" onClick={handleCheckout}>
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Proceed to Checkout
                </Button>
              </CardFooter>
            </Card>

            <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start">
              <Info className="h-5 w-5 text-blue-500 mr-3 mt-0.5 shrink-0" />
              <div>
                <h4 className="font-medium text-blue-800">About Our Carbon Credits</h4>
                <p className="text-sm text-blue-700 mt-1">
                  All carbon credits are backed by real atmospheric carbon capture at our facilities. Each credit is
                  tokenized on the blockchain, providing transparent verification and traceability. Upon purchase,
                  you'll receive a digital certificate and the ability to track the impact of your offset.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="mt-12 grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-green-100 rounded-full p-3 w-12 h-12 flex items-center justify-center mx-auto mb-4">
              <Leaf className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="font-medium mb-2">Verified Carbon Removal</h3>
            <p className="text-sm text-gray-600">
              Each credit represents one metric ton of CO₂ physically removed from the atmosphere by our facilities.
            </p>
          </div>
          <div className="text-center">
            <div className="bg-blue-100 rounded-full p-3 w-12 h-12 flex items-center justify-center mx-auto mb-4">
              <Shield className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="font-medium mb-2">Blockchain Verified</h3>
            <p className="text-sm text-gray-600">
              All credits are tokenized on the blockchain, providing transparent and immutable proof of your carbon
              offset.
            </p>
          </div>
          <div className="text-center">
            <div className="bg-purple-100 rounded-full p-3 w-12 h-12 flex items-center justify-center mx-auto mb-4">
              <BarChart className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="font-medium mb-2">Impact Tracking</h3>
            <p className="text-sm text-gray-600">
              Track the environmental impact of your carbon offset with detailed reports and analytics.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}

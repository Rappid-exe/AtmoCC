import "./styles.css"

export default function PurchaseCompleteLayout({ children }) {
  return children
}

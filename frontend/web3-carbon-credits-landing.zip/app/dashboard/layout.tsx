import "./styles.css"

export default function DashboardLayout({ children }) {
  return children
}

"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  CloudLightning,
  Filter,
  BarChart3,
  Download,
  Info,
  ShoppingCart,
  Cpu,
  Activity,
  BarChart2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

// Sample data for carbon capture locations
const locationData = [
  {
    id: 1,
    name: "Sierra Nevada Facility",
    state: "California",
    status: "Active",
    captureRate: "1,250",
    efficiency: "92%",
    lastUpdated: "2h ago",
    image: "/alpine-research-outpost.png",
  },
  {
    id: 2,
    name: "Gulf Coast Plant",
    state: "Texas",
    status: "Active",
    captureRate: "1,850",
    efficiency: "89%",
    lastUpdated: "4h ago",
    image: "/sprawling-industrial-complex.png",
  },
  {
    id: 3,
    name: "Great Lakes Center",
    state: "Michigan",
    status: "Active",
    captureRate: "980",
    efficiency: "91%",
    lastUpdated: "1h ago",
    image: "/serene-lakeside-retreat.png",
  },
  {
    id: 4,
    name: "Rocky Mountain Site",
    state: "Colorado",
    status: "Maintenance",
    captureRate: "650",
    efficiency: "85%",
    lastUpdated: "6h ago",
    image: "/alpine-research-outpost.png",
  },
  {
    id: 5,
    name: "Appalachian Facility",
    state: "Pennsylvania",
    status: "Active",
    captureRate: "1,120",
    efficiency: "90%",
    lastUpdated: "3h ago",
    image: "/woodland-research-outpost.png",
  },
  {
    id: 6,
    name: "Pacific Northwest Station",
    state: "Washington",
    status: "Active",
    captureRate: "1,340",
    efficiency: "94%",
    lastUpdated: "1h ago",
    image: "/woodland-research-outpost.png",
  },
  {
    id: 7,
    name: "Mojave Desert Array",
    state: "Nevada",
    status: "Active",
    captureRate: "1,750",
    efficiency: "96%",
    lastUpdated: "5h ago",
    image: "/desert-research-outpost.png",
  },
  {
    id: 8,
    name: "Atlantic Coast Facility",
    state: "North Carolina",
    status: "Maintenance",
    captureRate: "780",
    efficiency: "87%",
    lastUpdated: "12h ago",
    image: "/seaside-research-center.png",
  },
]

// Add this constant after the locationData array
const carbonAPISystems = [
  {
    id: "AC:XX0001",
    name: "System Alpha",
    status: "Active",
    captureRate: "1,420",
    efficiency: "94%",
    lastUpdated: "3m ago",
    color: "blue",
    icon: Cpu,
  },
  {
    id: "AC:XX0002",
    name: "System Beta",
    status: "Active",
    captureRate: "1,850",
    efficiency: "91%",
    lastUpdated: "7m ago",
    color: "green",
    icon: Activity,
  },
  {
    id: "AC:XX0003",
    name: "System Gamma",
    status: "Active",
    captureRate: "2,105",
    efficiency: "97%",
    lastUpdated: "1m ago",
    color: "purple",
    icon: BarChart2,
  },
]

// Define states grid layout
const statesGrid = [
  ["", "WA", "", "", "", "", "ME"],
  ["", "MT", "ND", "MN", "WI", "MI", "NY", "VT", "NH"],
  ["OR", "ID", "SD", "WY", "IA", "IL", "IN", "OH", "PA", "NJ", "MA"],
  ["CA", "NV", "UT", "CO", "NE", "MO", "KY", "WV", "VA", "MD", "CT", "RI"],
  ["", "AZ", "NM", "KS", "AR", "TN", "NC", "SC", "DE"],
  ["", "", "", "OK", "LA", "MS", "AL", "GA"],
  ["", "", "", "TX", "", "", "FL"],
]

export default function Dashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("grid")
  const [hoveredLocation, setHoveredLocation] = useState(null)

  const filteredLocations = locationData.filter(
    (location) =>
      location.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      location.state.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const totalCapture = locationData
    .filter((location) => location.status === "Active")
    .reduce((sum, location) => sum + Number.parseInt(location.captureRate.replace(",", "")), 0)
    .toLocaleString()

  const activeLocations = locationData.filter((location) => location.status === "Active").length

  // Create a map of state abbreviations to locations
  const stateLocations = {}
  locationData.forEach((location) => {
    // Map state names to abbreviations (simplified for our example)
    const stateToAbbreviation = {
      California: "CA",
      Texas: "TX",
      Michigan: "MI",
      Colorado: "CO",
      Pennsylvania: "PA",
      Washington: "WA",
      Nevada: "NV",
      "North Carolina": "NC",
    }

    const stateAbbr = stateToAbbreviation[location.state]
    if (stateAbbr) {
      stateLocations[stateAbbr] = location
    }
  })

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <h1 className="text-xl font-bold">ATMOSIEVE TECHNOLOGIES</h1>
              <Badge variant="outline" className="ml-2">
                Dashboard
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <BarChart3 className="h-4 w-4 mr-2" />
                Reports
              </Button>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Link href="/dashboard/purchase">
                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Buy Carbon Credits
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-2">Carbon Capture Locations</h2>
          <p className="text-gray-600">
            Monitoring real-time data from our atmospheric carbon capture facilities across the United States.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <CloudLightning className="h-5 w-5 text-blue-600" />
                <span className="text-sm font-medium">Total Active Capture</span>
              </div>
              <div className="mt-2 flex items-baseline">
                <span className="text-3xl font-bold">{totalCapture}</span>
                <span className="ml-1 text-sm text-gray-500">tons CO₂/day</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <CloudLightning className="h-5 w-5 text-green-600" />
                <span className="text-sm font-medium">Active Locations</span>
              </div>
              <div className="mt-2 flex items-baseline">
                <span className="text-3xl font-bold">{activeLocations}</span>
                <span className="ml-1 text-sm text-gray-500">of {locationData.length} sites</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <CloudLightning className="h-5 w-5 text-purple-600" />
                <span className="text-sm font-medium">Tokenized Credits</span>
              </div>
              <div className="mt-2 flex items-baseline">
                <span className="text-3xl font-bold">47,250</span>
                <span className="ml-1 text-sm text-gray-500">verified tokens</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Live Carbon Capture Systems</h2>
          <p className="text-gray-600 mb-6">
            Real-time monitoring of your live carbon capture systems with direct atmospheric extraction.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {carbonAPISystems.map((system) => (
              <motion.div
                key={system.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <CarbonAPISystemCard system={system} />
              </motion.div>
            ))}
          </div>
        </div>

        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">All Capture Locations</h2>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Tabs defaultValue="grid" className="w-[200px]" onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="grid">Grid View</TabsTrigger>
                <TabsTrigger value="map">Map View</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {activeTab === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredLocations.map((location) => (
              <motion.div
                key={location.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <LocationCard location={location} />
              </motion.div>
            ))}
          </div>
        ) : (
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">U.S. Carbon Capture Locations</h3>
            <TooltipProvider>
              <div className="grid-map-container">
                {statesGrid.map((row, rowIndex) => (
                  <div key={rowIndex} className="grid-map-row">
                    {row.map((state, colIndex) => {
                      const location = state ? stateLocations[state] : null
                      const isActive = location && location.status === "Active"
                      const isMaintenance = location && location.status === "Maintenance"

                      return (
                        <div
                          key={`${rowIndex}-${colIndex}`}
                          className={`grid-map-cell ${!state ? "grid-map-cell-empty" : ""}`}
                        >
                          {state && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div
                                  className={`state-cell ${isActive || isMaintenance ? "cursor-pointer" : ""}`}
                                  onMouseEnter={() => location && setHoveredLocation(location)}
                                  onMouseLeave={() => setHoveredLocation(null)}
                                >
                                  {state}
                                  {location && (
                                    <div
                                      className={`state-dot ${
                                        isActive ? "active-dot" : isMaintenance ? "maintenance-dot" : ""
                                      }`}
                                    ></div>
                                  )}
                                </div>
                              </TooltipTrigger>
                              {location && (
                                <TooltipContent side="top">
                                  <p className="font-semibold">{location.name}</p>
                                  <p className="text-xs text-gray-500">{location.state}</p>
                                  <div className="mt-1 grid grid-cols-2 gap-x-4 text-xs">
                                    <div>
                                      <p className="text-gray-500">Capture Rate</p>
                                      <p>{location.captureRate} tons/day</p>
                                    </div>
                                    <div>
                                      <p className="text-gray-500">Status</p>
                                      <p>{location.status}</p>
                                    </div>
                                  </div>
                                </TooltipContent>
                              )}
                            </Tooltip>
                          )}
                        </div>
                      )
                    })}
                  </div>
                ))}
              </div>
            </TooltipProvider>

            {hoveredLocation && (
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <h4 className="font-bold">{hoveredLocation.name}</h4>
                <p className="text-sm text-gray-500">{hoveredLocation.state}</p>
                <div className="mt-2 grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Capture Rate</p>
                    <p className="font-medium">{hoveredLocation.captureRate} tons/day</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Status</p>
                    <p className="font-medium">{hoveredLocation.status}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Efficiency</p>
                    <p className="font-medium">{hoveredLocation.efficiency}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Last Updated</p>
                    <p className="font-medium">{hoveredLocation.lastUpdated}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-4 flex gap-6">
              <div className="flex items-center">
                <div className="w-4 h-4 rounded-full bg-green-500 mr-2 animate-pulse"></div>
                <span className="text-sm">Active Locations</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 rounded-full bg-yellow-500 mr-2 animate-pulse"></div>
                <span className="text-sm">Maintenance Locations</span>
              </div>
              <div className="flex items-center ml-auto">
                <Info className="w-4 h-4 mr-2 text-gray-400" />
                <span className="text-sm text-gray-500">Hover over states with dots for details</span>
              </div>
            </div>
          </Card>
        )}
      </main>
    </div>
  )
}

function LocationCard({ location }) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative h-40 w-full">
        <img src={location.image || "/placeholder.svg"} alt={location.name} className="object-cover w-full h-full" />
        <div className="absolute top-2 right-2">
          <Badge variant={location.status === "Active" ? "default" : "secondary"}>{location.status}</Badge>
        </div>
      </div>
      <CardContent className="p-4">
        <h3 className="font-bold text-lg">{location.name}</h3>
        <p className="text-sm text-gray-500 mb-3">{location.state}</p>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <p className="text-gray-500">Capture Rate</p>
            <p className="font-medium">{location.captureRate} tons/day</p>
          </div>
          <div>
            <p className="text-gray-500">Efficiency</p>
            <p className="font-medium">{location.efficiency}</p>
          </div>
          <div className="col-span-2 mt-1">
            <p className="text-gray-500 text-xs">Last updated: {location.lastUpdated}</p>
          </div>
        </div>

        <div className="mt-3 flex justify-end">
          <Button variant="ghost" size="sm" className="text-xs">
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

// Add this new component after the LocationCard component at the bottom of the file
function CarbonAPISystemCard({ system }) {
  const colorMap = {
    blue: "bg-blue-500",
    green: "bg-green-500",
    purple: "bg-purple-500",
  }

  const bgColorMap = {
    blue: "bg-blue-50",
    green: "bg-green-50",
    purple: "bg-purple-50",
  }

  const textColorMap = {
    blue: "text-blue-700",
    green: "text-green-700",
    purple: "text-purple-700",
  }

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <CardContent className="p-0">
        <div className={`${bgColorMap[system.color]} p-4`}>
          <div className="flex justify-between items-start">
            <div>
              <h3 className={`font-bold text-xl ${textColorMap[system.color]}`}>{system.name}</h3>
              <p className="text-sm text-gray-500 mt-1">ID: {system.id}</p>
            </div>
            <div className={`${colorMap[system.color]} text-white p-2 rounded-full`}>
              <system.icon className="h-6 w-6" />
            </div>
          </div>

          <div className="mt-4">
            <div className="flex items-center">
              <div className={`h-2 rounded-full ${colorMap[system.color]} flex-1`}>
                <div className="h-full bg-white/30 rounded-full" style={{ width: system.efficiency }}></div>
              </div>
              <span className="ml-2 text-sm font-medium">{system.efficiency}</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">Efficiency Rating</p>
          </div>
        </div>

        <div className="p-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Capture Rate</p>
              <p className="font-bold text-lg">{system.captureRate}</p>
              <p className="text-xs text-gray-500">tons CO₂/day</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Status</p>
              <div className="flex items-center">
                <div className={`w-2 h-2 rounded-full ${colorMap[system.color]} mr-2 animate-pulse`}></div>
                <p className="font-bold">{system.status}</p>
              </div>
              <p className="text-xs text-gray-500">Updated {system.lastUpdated}</p>
            </div>
          </div>

          <div className="mt-4 flex justify-end">
            <Button variant="ghost" size="sm" className="text-xs">
              View Details
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
